import os
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    container_can_config = os.path.join(
        get_package_share_directory("rover_peripherals"),
        "config", "container_can.yaml"
    )

    return LaunchDescription([
        Node(
            package="rover_peripherals",
            executable="rover_container_node",
            parameters=[container_can_config],
        ),
    ])